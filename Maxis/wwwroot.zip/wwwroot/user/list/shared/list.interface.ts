﻿export interface Userlist {
    userId: number;
    userName: string;
    emailId: string;
    mobileNo: number;
    department: string;
    title: string;
    status: number;
    roles: string;
}
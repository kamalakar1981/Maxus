﻿export interface Map {
}
    
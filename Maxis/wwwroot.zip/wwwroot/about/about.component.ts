﻿import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'about',
    templateUrl: 'wwwroot/about/about.component.html',
    styleUrls: ['wwwroot/about/about.component.css']
})

export class AboutComponent {
    title = 'About Component';
}
﻿import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'contact',
    templateUrl: 'wwwroot/contact/contact.component.html',
    styleUrls: ['wwwroot/contact/contact.component.css']
})

export class ContactComponent {
    title = 'Contact Component';
}